from ..Require import *

from ..Core.Types import *
from ..Core.Object import *





__all__ = ("RFT_Saves",)





class RFT_Saves(RFT_Object):
	def __init__(self) -> None:
		...




