from ...Require import *





__all__ = ("closeEvent",)





def closeEvent(self, event):
	self.exit()



